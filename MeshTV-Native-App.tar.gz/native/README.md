# MeshTV Native App

## 100% Native Mobile App - No Server Required

MeshTV Native is a complete React Native mobile application that runs entirely on the user's device. All YouTube API calls, data processing, and video streaming happen client-side with no server dependencies.

### 🚀 Key Features

- **100% Client-Side Operation**: No servers, no hosting required
- **User-Provided API Keys**: Each user provides their own YouTube API key
- **150+ Video Playlist**: Automatically fetches from tv.meshnews.org redirect
- **Background Audio**: Continuous playback with system media controls
- **Native Video Player**: YouTube iframe with fullscreen support
- **Creator Profiles**: Automatic newsmaker detection and statistics
- **Dark Theme**: Netflix-style interface with orange accent
- **Offline Caching**: Smart caching prevents redundant API calls

### 📱 Setup & Installation

#### Prerequisites
- Node.js 16+ installed
- Expo CLI installed globally: `npm install -g expo-cli`
- Android Studio (for Android builds) or Xcode (for iOS builds)

#### Getting Started

1. **Initialize the project:**
   ```bash
   npx expo init MeshTV --template blank-typescript
   cd MeshTV
   ```

2. **Copy the native app files:**
   Copy all files from the `native/` directory to your Expo project

3. **Install dependencies:**
   ```bash
   npm install
   ```

4. **Start development server:**
   ```bash
   expo start
   ```

### 🔑 User Setup Process

When users first launch the app, they'll need to:

1. **Get YouTube API Key:**
   - Go to [Google Cloud Console](https://console.cloud.google.com/)
   - Create a new project or select existing
   - Enable YouTube Data API v3
   - Create credentials (API key)
   - Copy the key

2. **Enter API Key in App:**
   - Paste the key in the setup screen
   - App validates the key automatically
   - Key is stored locally on device only

### 🏗️ Architecture

#### Client-Side Services
- **YouTubeService**: Direct API calls to YouTube Data API v3
- **VideoProvider**: State management for playlist and playback
- **ThemeProvider**: Dark theme with MeshNews orange branding

#### Core Screens
- **APIKeySetupScreen**: Initial user setup for YouTube API key
- **HomeScreen**: Main dashboard with navigation options
- **PlaylistScreen**: Video player with scrollable playlist
- **CreatorsScreen**: Newsmaker profiles and statistics
- **MeshNewsScreen**: WebView of original MeshNews.org site
- **SettingsScreen**: API key management and app preferences

#### Native Components
- **NativeVideoPlayer**: YouTube iframe with native controls
- Custom UI components built with React Native primitives

### 📦 Building for Distribution

#### Android APK
```bash
expo build:android
```

#### iOS App Store
```bash
expo build:ios
```

#### Standalone Apps
The app can be distributed as:
- APK file for Android sideloading
- iOS app through App Store or TestFlight
- Expo Go app for development/testing

### 🔒 Security & Privacy

- **No Server Communication**: App only talks to YouTube API directly
- **Local Storage Only**: API keys stored in device AsyncStorage
- **User-Controlled**: Users provide their own API keys and data
- **No Tracking**: No analytics or user data collection

### 🎯 Deployment Strategy

**For Users:**
1. Download APK or install from App Store
2. Get free YouTube API key (takes 2 minutes)
3. Enter key in app setup
4. Enjoy 24/7 decentralized news!

**No Server Costs:**
- Zero hosting fees
- Zero maintenance
- Zero scaling issues
- Users handle all compute and API costs

### 🛠️ Technical Details

- **React Native 0.72+** with TypeScript
- **Expo SDK 49** for easy deployment
- **AsyncStorage** for local data persistence
- **React Navigation** for screen management
- **YouTube iframe** for video playback
- **Fetch API** for YouTube Data API v3 calls

### 📋 Development Notes

The app is designed to be completely self-contained:
- No backend server required
- No database connections
- No user authentication systems
- No content management needed

Users provide their own:
- YouTube API quota (free tier: 10,000 requests/day)
- Device storage for caching
- Network bandwidth for video streaming

This architecture ensures the app can run independently on any device without relying on external infrastructure.