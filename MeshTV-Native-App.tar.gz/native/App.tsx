import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TextInput, 
  TouchableOpacity, 
  ScrollView,
  Alert,
  Dimensions
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { WebView } from 'react-native-webview';
import AsyncStorage from '@react-native-async-storage/async-storage';

const { width, height } = Dimensions.get('window');

interface Video {
  id: string;
  title: string;
  thumbnail: string;
  channelTitle: string;
}

export default function App() {
  const [apiKey, setApiKey] = useState('');
  const [isSetup, setIsSetup] = useState(false);
  const [videos, setVideos] = useState<Video[]>([]);
  const [currentVideo, setCurrentVideo] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadApiKey();
  }, []);

  const loadApiKey = async () => {
    try {
      const savedKey = await AsyncStorage.getItem('youtube_api_key');
      if (savedKey) {
        setApiKey(savedKey);
        setIsSetup(true);
        loadPlaylist();
      }
    } catch (error) {
      console.error('Error loading API key:', error);
    }
  };

  const saveApiKey = async () => {
    if (!apiKey.trim()) {
      Alert.alert('Error', 'Please enter your YouTube API key');
      return;
    }
    
    try {
      await AsyncStorage.setItem('youtube_api_key', apiKey);
      setIsSetup(true);
      loadPlaylist();
    } catch (error) {
      Alert.alert('Error', 'Failed to save API key');
    }
  };

  const loadPlaylist = async () => {
    setLoading(true);
    try {
      // MeshNews playlist ID
      const playlistId = 'PLtdhuSRYmPO1_Jb7c9vYQaK5qJKqSYUoc';
      const response = await fetch(
        `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=${playlistId}&maxResults=50&key=${apiKey}`
      );
      
      if (!response.ok) {
        throw new Error('Failed to fetch playlist');
      }
      
      const data = await response.json();
      const videoList = data.items.map((item: any) => ({
        id: item.snippet.resourceId.videoId,
        title: item.snippet.title,
        thumbnail: item.snippet.thumbnails.medium.url,
        channelTitle: item.snippet.channelTitle,
      }));
      
      setVideos(videoList);
      if (videoList.length > 0) {
        setCurrentVideo(videoList[0].id);
      }
    } catch (error) {
      console.error('Error loading playlist:', error);
      Alert.alert('Error', 'Failed to load videos. Please check your API key.');
    } finally {
      setLoading(false);
    }
  };

  const resetApp = async () => {
    await AsyncStorage.removeItem('youtube_api_key');
    setApiKey('');
    setIsSetup(false);
    setVideos([]);
    setCurrentVideo(null);
  };

  if (!isSetup) {
    return (
      <View style={styles.container}>
        <StatusBar style="light" />
        <View style={styles.setupContainer}>
          <Text style={styles.title}>🔴 MeshTV</Text>
          <Text style={styles.subtitle}>24/7 Decentralized News</Text>
          
          <Text style={styles.description}>
            Enter your YouTube API key to start streaming news videos
          </Text>
          
          <TextInput
            style={styles.input}
            placeholder="YouTube API Key"
            placeholderTextColor="#666"
            value={apiKey}
            onChangeText={setApiKey}
            secureTextEntry
            data-testid="input-api-key"
          />
          
          <TouchableOpacity 
            style={styles.button} 
            onPress={saveApiKey}
            data-testid="button-save-key"
          >
            <Text style={styles.buttonText}>Start Streaming</Text>
          </TouchableOpacity>
          
          <Text style={styles.helpText}>
            Get your free API key from Google Cloud Console
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>🔴 MeshTV</Text>
        <TouchableOpacity 
          style={styles.resetButton} 
          onPress={resetApp}
          data-testid="button-reset"
        >
          <Text style={styles.resetText}>⚙️</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.content}>
        {/* Video Player */}
        {currentVideo && (
          <View style={styles.videoContainer}>
            <WebView
              source={{ 
                uri: `https://www.youtube.com/embed/${currentVideo}?autoplay=1&controls=1&rel=0&showinfo=0&modestbranding=1&playsinline=1` 
              }}
              style={styles.video}
              allowsInlineMediaPlayback
              allowsFullscreenVideo
              mediaPlaybackRequiresUserAction={false}
              javaScriptEnabled
              domStorageEnabled
              data-testid="video-player"
            />
          </View>
        )}

        {/* Playlist */}
        <View style={styles.playlistContainer}>
          <Text style={styles.playlistTitle}>📺 Live News Feed</Text>
          
          {loading ? (
            <Text style={styles.loadingText}>Loading videos...</Text>
          ) : (
            <ScrollView style={styles.videoList}>
              {videos.map((video) => (
                <TouchableOpacity
                  key={video.id}
                  style={[
                    styles.videoItem,
                    currentVideo === video.id && styles.activeVideoItem
                  ]}
                  onPress={() => setCurrentVideo(video.id)}
                  data-testid={`video-item-${video.id}`}
                >
                  <Text style={styles.videoTitle} numberOfLines={2}>
                    {video.title}
                  </Text>
                  <Text style={styles.channelTitle}>
                    {video.channelTitle}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          )}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  setupContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FF6B35',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 16,
    color: '#fff',
    marginBottom: 30,
    textAlign: 'center',
  },
  description: {
    fontSize: 14,
    color: '#ccc',
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 20,
  },
  input: {
    width: '100%',
    height: 50,
    backgroundColor: '#222',
    color: '#fff',
    borderRadius: 8,
    paddingHorizontal: 15,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#333',
  },
  button: {
    backgroundColor: '#FF6B35',
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderRadius: 8,
    marginBottom: 20,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  helpText: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 15,
    paddingVertical: 10,
    backgroundColor: '#111',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FF6B35',
  },
  resetButton: {
    padding: 5,
  },
  resetText: {
    fontSize: 18,
    color: '#fff',
  },
  content: {
    flex: 1,
  },
  videoContainer: {
    height: height * 0.3,
    backgroundColor: '#000',
  },
  video: {
    flex: 1,
  },
  playlistContainer: {
    flex: 1,
    backgroundColor: '#111',
  },
  playlistTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FF6B35',
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  loadingText: {
    color: '#fff',
    textAlign: 'center',
    padding: 20,
  },
  videoList: {
    flex: 1,
  },
  videoItem: {
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  activeVideoItem: {
    backgroundColor: '#FF6B35',
  },
  videoTitle: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  channelTitle: {
    color: '#666',
    fontSize: 12,
  },
});