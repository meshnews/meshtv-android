import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TextInput, 
  TouchableOpacity, 
  ScrollView,
  Alert,
  Dimensions
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { WebView } from 'react-native-webview';
import AsyncStorage from '@react-native-async-storage/async-storage';

const { width, height } = Dimensions.get('window');

interface Video {
  id: string;
  title: string;
  thumbnail: string;
  channelTitle: string;
}

export default function App() {
  const [apiKey, setApiKey] = useState('');
  const [isSetup, setIsSetup] = useState(false);
  const [videos, setVideos] = useState<Video[]>([]);
  const [currentVideo, setCurrentVideo] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadApiKey();
  }, []);

  const loadApiKey = async () => {
    try {
      const savedKey = await AsyncStorage.getItem('youtube_api_key');
      if (savedKey) {
        setApiKey(savedKey);
        setIsSetup(true);
        loadPlaylist();
      }
    } catch (error) {
      console.error('Error loading API key:', error);
    }
  };

  const saveApiKey = async () => {
    if (!apiKey.trim()) {
      Alert.alert('Error', 'Please enter your YouTube API key');
      return;
    }
    
    try {
      await AsyncStorage.setItem('youtube_api_key', apiKey);
      setIsSetup(true);
      loadPlaylist();
    } catch (error) {
      Alert.alert('Error', 'Failed to save API key');
    }
  };

  const loadPlaylist = async () => {
    setLoading(true);
    try {
      // MeshNews playlist ID
      const playlistId = 'PLtdhuSRYmPO1_Jb7c9vYQaK5qJKqSYUoc';
      const response = await fetch(
        `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=${playlistId}&maxResults=50&key=${apiKey}`
      );
      
      if (!response.ok) {
        throw new Error('Failed to fetch playlist');
      }
      
      const data = await response.json();
      const videoList = data.items.map((item: any) => ({
        id: item.snippet.resourceId.videoId,
        title: item.snippet.title,
        thumbnail: item.snippet.thumbnails.medium.url,
        channelTitle: item.snippet.channelTitle,
      }));
      
      setVideos(videoList);
      if (videoList.length > 0) {
        setCurrentVideo(videoList[0].id);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to load videos. Check your API key.');
    } finally {
      setLoading(false);
    }
  };

  const resetApp = async () => {
    await AsyncStorage.removeItem('youtube_api_key');
    setApiKey('');
    setIsSetup(false);
    setVideos([]);
    setCurrentVideo(null);
  };

  if (!isSetup) {
    return (
      <View style={styles.container}>
        <StatusBar style="light" />
        <View style={styles.setupContainer}>
          <Text style={styles.title}>🎥 MeshTV</Text>
          <Text style={styles.subtitle}>24/7 Decentralized News</Text>
          
          <Text style={styles.label}>YouTube API Key:</Text>
          <TextInput
            style={styles.input}
            value={apiKey}
            onChangeText={setApiKey}
            placeholder="Enter your YouTube API key"
            placeholderTextColor="#666"
            secureTextEntry
          />
          
          <TouchableOpacity style={styles.button} onPress={saveApiKey}>
            <Text style={styles.buttonText}>Save & Continue</Text>
          </TouchableOpacity>
          
          <Text style={styles.helpText}>
            Get your free API key from Google Cloud Console → YouTube Data API v3
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>🎥 MeshTV</Text>
        <TouchableOpacity onPress={resetApp} style={styles.resetButton}>
          <Text style={styles.resetText}>Reset</Text>
        </TouchableOpacity>
      </View>

      {/* Video Player */}
      {currentVideo && (
        <View style={styles.playerContainer}>
          <WebView
            source={{ 
              uri: `https://www.youtube.com/embed/${currentVideo}?autoplay=1&rel=0&modestbranding=1` 
            }}
            style={styles.webview}
            allowsInlineMediaPlayback
            mediaPlaybackRequiresUserAction={false}
          />
        </View>
      )}

      {/* Playlist */}
      <View style={styles.playlistContainer}>
        <Text style={styles.playlistTitle}>📺 News Playlist</Text>
        {loading ? (
          <Text style={styles.loadingText}>Loading videos...</Text>
        ) : (
          <ScrollView style={styles.videoList}>
            {videos.map((video, index) => (
              <TouchableOpacity
                key={video.id}
                style={[
                  styles.videoItem,
                  currentVideo === video.id && styles.activeVideoItem
                ]}
                onPress={() => setCurrentVideo(video.id)}
              >
                <Text style={styles.videoTitle} numberOfLines={2}>
                  {video.title}
                </Text>
                <Text style={styles.channelTitle}>{video.channelTitle}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  setupContainer: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FF6B35',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#fff',
    textAlign: 'center',
    marginBottom: 40,
  },
  label: {
    fontSize: 16,
    color: '#fff',
    marginBottom: 10,
  },
  input: {
    backgroundColor: '#333',
    color: '#fff',
    padding: 15,
    borderRadius: 8,
    marginBottom: 20,
    fontSize: 16,
  },
  button: {
    backgroundColor: '#FF6B35',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  helpText: {
    color: '#666',
    textAlign: 'center',
    marginTop: 20,
    fontSize: 12,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    backgroundColor: '#111',
    paddingTop: 50,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FF6B35',
  },
  resetButton: {
    padding: 8,
  },
  resetText: {
    color: '#666',
    fontSize: 14,
  },
  playerContainer: {
    height: 220,
    backgroundColor: '#000',
  },
  webview: {
    flex: 1,
  },
  playlistContainer: {
    flex: 1,
    backgroundColor: '#111',
  },
  playlistTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    padding: 15,
    backgroundColor: '#222',
  },
  loadingText: {
    color: '#666',
    textAlign: 'center',
    padding: 20,
  },
  videoList: {
    flex: 1,
  },
  videoItem: {
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  activeVideoItem: {
    backgroundColor: '#FF6B35',
  },
  videoTitle: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  channelTitle: {
    color: '#666',
    fontSize: 12,
  },
});