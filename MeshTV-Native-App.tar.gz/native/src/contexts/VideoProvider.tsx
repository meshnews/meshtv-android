/**
 * Native Video Provider - Handles video state and playback for native app
 */

import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { youTubeService, Video } from '../services/YouTubeService';

interface VideoContextType {
  currentVideoId: string | null;
  currentVideo: Video | null;
  setCurrentVideoId: (videoId: string) => void;
  isFullscreen: boolean;
  setIsFullscreen: (fullscreen: boolean) => void;
  toggleFullscreen: () => void;
  nextTrack: () => void;
  previousTrack: () => void;
  playlist: Video[];
  isLoading: boolean;
  error: string | null;
  refreshPlaylist: () => Promise<void>;
}

const VideoContext = createContext<VideoContextType | undefined>(undefined);

export function VideoProvider({ children }: { children: ReactNode }) {
  const [currentVideoId, setCurrentVideoId] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [playlist, setPlaylist] = useState<Video[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const currentVideo = playlist.find(video => video.id === currentVideoId) || null;

  const toggleFullscreen = useCallback(() => {
    setIsFullscreen(!isFullscreen);
  }, [isFullscreen]);

  const nextTrack = useCallback(() => {
    console.log('Next track triggered');
    if (playlist.length === 0) return;
    
    const currentIndex = playlist.findIndex(video => video.id === currentVideoId);
    if (currentIndex !== -1 && currentIndex < playlist.length - 1) {
      const nextVideo = playlist[currentIndex + 1];
      console.log('Advancing to next video:', nextVideo.id);
      setCurrentVideoId(nextVideo.id);
    } else if (playlist.length > 0) {
      console.log('Looping back to first video:', playlist[0].id);
      setCurrentVideoId(playlist[0].id);
    }
  }, [playlist, currentVideoId]);

  const previousTrack = useCallback(() => {
    console.log('Previous track triggered');
    if (playlist.length === 0) return;
    
    const currentIndex = playlist.findIndex(video => video.id === currentVideoId);
    if (currentIndex > 0) {
      const previousVideo = playlist[currentIndex - 1];
      console.log('Going to previous video:', previousVideo.id);
      setCurrentVideoId(previousVideo.id);
    } else if (playlist.length > 0) {
      console.log('Going to last video:', playlist[playlist.length - 1].id);
      setCurrentVideoId(playlist[playlist.length - 1].id);
    }
  }, [playlist, currentVideoId]);

  const refreshPlaylist = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const playlistData = await youTubeService.getMeshNewsPlaylist();
      setPlaylist(playlistData.videos);
      
      if (!currentVideoId && playlistData.videos.length > 0) {
        setCurrentVideoId(playlistData.videos[0].id);
      }
      
      console.log(`Loaded ${playlistData.videos.length} videos from MeshNews playlist`);
    } catch (error) {
      console.error('Failed to load playlist:', error);
      setError(error instanceof Error ? error.message : 'Failed to load playlist');
    } finally {
      setIsLoading(false);
    }
  }, [currentVideoId]);

  useEffect(() => {
    refreshPlaylist();
  }, [refreshPlaylist]);

  return (
    <VideoContext.Provider value={{
      currentVideoId,
      currentVideo,
      setCurrentVideoId,
      isFullscreen,
      setIsFullscreen,
      toggleFullscreen,
      nextTrack,
      previousTrack,
      playlist,
      isLoading,
      error,
      refreshPlaylist,
    }}>
      {children}
    </VideoContext.Provider>
  );
}

export function useVideo() {
  const context = useContext(VideoContext);
  if (context === undefined) {
    throw new Error('useVideo must be used within a VideoProvider');
  }
  return context;
}