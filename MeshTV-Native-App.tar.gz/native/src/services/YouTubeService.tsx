/**
 * Native YouTube Service - 100% client-side YouTube API integration
 * Handles all video data fetching directly on user's device
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

export interface Video {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  duration: string;
  viewCount: number;
  publishedAt: string;
  channelTitle: string;
}

export interface Playlist {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  channelTitle: string;
  videos: Video[];
}

class YouTubeService {
  private apiKey: string | null = null;
  private cache: Map<string, any> = new Map();
  private readonly CACHE_DURATION = 5 * 60 * 1000; // 5 minutes
  private readonly MESHNEWS_URL = "https://tv.meshnews.org";

  async initialize(): Promise<void> {
    this.apiKey = await AsyncStorage.getItem('youtube_api_key');
    if (!this.apiKey) {
      throw new Error('YouTube API key not found. Please set it in settings.');
    }
  }

  async setApiKey(apiKey: string): Promise<void> {
    await AsyncStorage.setItem('youtube_api_key', apiKey);
    this.apiKey = apiKey;
  }

  async validateApiKey(apiKey?: string): Promise<boolean> {
    const keyToTest = apiKey || this.apiKey;
    if (!keyToTest) return false;

    try {
      const testUrl = `https://www.googleapis.com/youtube/v3/playlists?part=snippet&id=PLrAXtmRdnEQy1_6KjGq2jNlqfKSv3qzLj&key=${keyToTest}`;
      const response = await fetch(testUrl);
      return response.ok;
    } catch {
      return false;
    }
  }

  private async getPlaylistIdFromMeshNews(): Promise<string> {
    try {
      const response = await fetch(this.MESHNEWS_URL, {
        method: 'GET',
        redirect: 'follow',
      });
      
      const finalUrl = response.url;
      const playlistMatch = finalUrl.match(/[?&]list=([a-zA-Z0-9_-]+)/);
      
      if (playlistMatch) {
        return playlistMatch[1];
      }
      
      throw new Error("Could not extract playlist ID from redirect");
    } catch (error) {
      console.error("Error following redirect:", error);
      throw new Error("Failed to fetch playlist from tv.meshnews.org");
    }
  }

  private async fetchPlaylistItems(playlistId: string): Promise<any[]> {
    if (!this.apiKey) {
      await this.initialize();
    }

    let allItems: any[] = [];
    let nextPageToken: string | undefined;
    const maxVideos = 150;
    const batchSize = 50;

    for (let batch = 0; batch < 3 && allItems.length < maxVideos; batch++) {
      try {
        const url = `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=${playlistId}&maxResults=${batchSize}&key=${this.apiKey}${nextPageToken ? `&pageToken=${nextPageToken}` : ''}`;
        
        const response = await fetch(url);
        const data = await response.json();

        if (!response.ok) {
          throw new Error(`YouTube API error: ${data.error?.message || 'Unknown error'}`);
        }

        allItems = [...allItems, ...data.items];
        nextPageToken = data.nextPageToken;

        console.log(`Fetched batch ${batch + 1}: ${data.items.length} videos (total: ${allItems.length})`);

        if (!nextPageToken) break;
      } catch (error) {
        console.error(`Error fetching batch ${batch + 1}:`, error);
        if (batch === 0) throw error;
        break;
      }
    }

    return allItems.slice(0, maxVideos);
  }

  private async fetchVideoDetails(videoIds: string[]): Promise<any[]> {
    if (!this.apiKey) {
      await this.initialize();
    }

    const allVideoDetails: any[] = [];
    const batchSize = 50;

    for (let i = 0; i < videoIds.length; i += batchSize) {
      const batchIds = videoIds.slice(i, i + batchSize).join(',');
      
      try {
        const url = `https://www.googleapis.com/youtube/v3/videos?part=contentDetails,statistics&id=${batchIds}&key=${this.apiKey}`;
        
        const response = await fetch(url);
        const data = await response.json();

        if (!response.ok) {
          throw new Error(`YouTube API error: ${data.error?.message || 'Unknown error'}`);
        }

        allVideoDetails.push(...data.items);
      } catch (error) {
        console.error(`Error fetching video details batch:`, error);
      }
    }

    return allVideoDetails;
  }

  private formatDuration(isoDuration: string): string {
    const match = isoDuration.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
    if (!match) return "0:00";

    const hours = parseInt(match[1] || '0');
    const minutes = parseInt(match[2] || '0');
    const seconds = parseInt(match[3] || '0');

    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
    }
    return `${minutes}:${seconds.toString().padStart(2, "0")}`;
  }

  private async getCachedOrFetch<T>(key: string, fetchFn: () => Promise<T>): Promise<T> {
    const cached = this.cache.get(key);
    if (cached && Date.now() - cached.timestamp < this.CACHE_DURATION) {
      console.log(`Using cached data for: ${key}`);
      return cached.data;
    }

    console.log(`Fetching fresh data for: ${key}`);
    const data = await fetchFn();
    this.cache.set(key, { data, timestamp: Date.now() });
    return data;
  }

  async getMeshNewsPlaylist(): Promise<Playlist> {
    return this.getCachedOrFetch('meshnews-playlist', async () => {
      const playlistId = await this.getPlaylistIdFromMeshNews();
      
      const playlistUrl = `https://www.googleapis.com/youtube/v3/playlists?part=snippet&id=${playlistId}&key=${this.apiKey}`;
      const playlistResponse = await fetch(playlistUrl);
      const playlistData = await playlistResponse.json();

      if (!playlistResponse.ok || !playlistData.items?.length) {
        throw new Error(`Playlist not found: ${playlistData.error?.message || 'Unknown error'}`);
      }

      const playlist = playlistData.items[0];
      const playlistItems = await this.fetchPlaylistItems(playlistId);
      
      const videoIds = playlistItems
        .map((item: any) => item.snippet.resourceId.videoId)
        .filter(Boolean);

      const videoDetails = await this.fetchVideoDetails(videoIds);
      
      const videoDetailsMap = new Map();
      videoDetails.forEach((video: any) => {
        videoDetailsMap.set(video.id, video);
      });

      const videos: Video[] = playlistItems
        .map((item: any) => {
          const videoId = item.snippet.resourceId.videoId;
          const details = videoDetailsMap.get(videoId);
          
          return {
            id: videoId,
            title: item.snippet.title,
            description: item.snippet.description || '',
            thumbnail: item.snippet.thumbnails?.medium?.url || item.snippet.thumbnails?.default?.url || '',
            duration: details ? this.formatDuration(details.contentDetails.duration) : '0:00',
            viewCount: details ? parseInt(details.statistics.viewCount || '0') : 0,
            publishedAt: item.snippet.publishedAt,
            channelTitle: item.snippet.channelTitle || item.snippet.videoOwnerChannelTitle || '',
          };
        })
        .filter((video: Video) => video.id);

      console.log(`Successfully loaded ${videos.length} videos from MeshNews playlist`);

      return {
        id: playlistId,
        title: playlist.snippet.title,
        description: playlist.snippet.description || '',
        thumbnail: playlist.snippet.thumbnails?.medium?.url || playlist.snippet.thumbnails?.default?.url || '',
        channelTitle: playlist.snippet.channelTitle,
        videos,
      };
    });
  }

  async getVideoDetails(videoId: string): Promise<Video | null> {
    try {
      const playlist = await this.getMeshNewsPlaylist();
      return playlist.videos.find(video => video.id === videoId) || null;
    } catch (error) {
      console.error('Error getting video details:', error);
      return null;
    }
  }

  clearCache(): void {
    this.cache.clear();
    console.log('YouTube service cache cleared');
  }
}

export const youTubeService = new YouTubeService();