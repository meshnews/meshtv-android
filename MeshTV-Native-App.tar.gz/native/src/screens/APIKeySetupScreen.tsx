/**
 * API Key Setup Screen - Native version for user YouTube API key input
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  Linking,
  ScrollView,
  SafeAreaView,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { youTubeService } from '../services/YouTubeService';
import { useTheme } from '../contexts/ThemeProvider';

interface APIKeySetupScreenProps {
  onApiKeySet: () => void;
}

export default function APIKeySetupScreen({ onApiKeySet }: APIKeySetupScreenProps) {
  const { theme } = useTheme();
  const [apiKey, setApiKey] = useState('');
  const [isValidating, setIsValidating] = useState(false);
  const [hasExistingKey, setHasExistingKey] = useState(false);

  useEffect(() => {
    checkExistingApiKey();
  }, []);

  const checkExistingApiKey = async () => {
    try {
      const existingKey = await AsyncStorage.getItem('youtube_api_key');
      if (existingKey) {
        setHasExistingKey(true);
        setApiKey(existingKey);
      }
    } catch (error) {
      console.error('Error checking existing API key:', error);
    }
  };

  const validateAndSaveApiKey = async () => {
    if (!apiKey.trim()) {
      Alert.alert('Error', 'Please enter a YouTube API key');
      return;
    }

    setIsValidating(true);
    
    try {
      const isValid = await youTubeService.validateApiKey(apiKey.trim());
      
      if (isValid) {
        await youTubeService.setApiKey(apiKey.trim());
        Alert.alert(
          'Success', 
          'YouTube API key has been saved successfully!',
          [{ text: 'Continue', onPress: onApiKeySet }]
        );
      } else {
        Alert.alert(
          'Invalid API Key', 
          'The YouTube API key you entered is not valid. Please check and try again.'
        );
      }
    } catch (error) {
      Alert.alert(
        'Error', 
        'Failed to validate API key. Please check your internet connection and try again.'
      );
    } finally {
      setIsValidating(false);
    }
  };

  const openAPIKeyGuide = () => {
    Linking.openURL('https://developers.google.com/youtube/v3/getting-started');
  };

  const skipSetup = () => {
    if (hasExistingKey) {
      onApiKeySet();
    }
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={[styles.content, { backgroundColor: theme.colors.surface }]}>
          <Text style={[styles.title, { color: theme.colors.text }]}>
            YouTube API Key Required
          </Text>
          
          <Text style={[styles.description, { color: theme.colors.textSecondary }]}>
            To use MeshTV natively on your device, you need to provide your own YouTube API key. 
            This ensures the app works independently without requiring our servers.
          </Text>

          <View style={[styles.steps, { backgroundColor: theme.colors.background }]}>
            <Text style={[styles.stepTitle, { color: theme.colors.text }]}>
              How to get your API key:
            </Text>
            <Text style={[styles.step, { color: theme.colors.textSecondary }]}>
              1. Go to Google Cloud Console
            </Text>
            <Text style={[styles.step, { color: theme.colors.textSecondary }]}>
              2. Create a new project or select existing
            </Text>
            <Text style={[styles.step, { color: theme.colors.textSecondary }]}>
              3. Enable YouTube Data API v3
            </Text>
            <Text style={[styles.step, { color: theme.colors.textSecondary }]}>
              4. Create credentials (API key)
            </Text>
            <Text style={[styles.step, { color: theme.colors.textSecondary }]}>
              5. Copy and paste the key below
            </Text>
          </View>

          <TouchableOpacity style={[styles.guideButton, { backgroundColor: theme.colors.accent }]} onPress={openAPIKeyGuide}>
            <Text style={styles.guideButtonText}>Open Setup Guide</Text>
          </TouchableOpacity>

          <TextInput
            style={[styles.input, { backgroundColor: theme.colors.background, color: theme.colors.text, borderColor: theme.colors.border }]}
            placeholder="Enter your YouTube API key here..."
            placeholderTextColor={theme.colors.textSecondary}
            value={apiKey}
            onChangeText={setApiKey}
            autoCapitalize="none"
            autoCorrect={false}
            multiline={true}
            numberOfLines={3}
          />

          <TouchableOpacity 
            style={[styles.button, { backgroundColor: isValidating ? theme.colors.border : theme.colors.accent }]} 
            onPress={validateAndSaveApiKey}
            disabled={isValidating}
          >
            <Text style={styles.buttonText}>
              {isValidating ? 'Validating...' : hasExistingKey ? 'Update API Key' : 'Save API Key'}
            </Text>
          </TouchableOpacity>

          {hasExistingKey && (
            <TouchableOpacity style={styles.skipButton} onPress={skipSetup}>
              <Text style={[styles.skipButtonText, { color: theme.colors.accent }]}>
                Continue with existing key
              </Text>
            </TouchableOpacity>
          )}

          <Text style={[styles.note, { color: theme.colors.textSecondary }]}>
            Your API key is stored locally on your device and never shared with our servers. 
            You can change it anytime in settings.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 20,
  },
  content: {
    borderRadius: 12,
    padding: 24,
    marginHorizontal: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 16,
  },
  description: {
    fontSize: 16,
    lineHeight: 24,
    marginBottom: 20,
    textAlign: 'center',
  },
  steps: {
    borderRadius: 8,
    padding: 16,
    marginBottom: 20,
  },
  stepTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
  },
  step: {
    fontSize: 14,
    marginBottom: 6,
    paddingLeft: 8,
  },
  guideButton: {
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 20,
    marginBottom: 20,
    alignSelf: 'center',
  },
  guideButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  input: {
    borderRadius: 8,
    padding: 16,
    fontSize: 16,
    marginBottom: 20,
    minHeight: 80,
    textAlignVertical: 'top',
    borderWidth: 1,
  },
  button: {
    borderRadius: 8,
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: 'center',
    marginBottom: 12,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
  skipButton: {
    paddingVertical: 12,
    alignItems: 'center',
    marginBottom: 20,
  },
  skipButtonText: {
    fontSize: 16,
    textDecorationLine: 'underline',
  },
  note: {
    fontSize: 12,
    textAlign: 'center',
    lineHeight: 18,
  },
});