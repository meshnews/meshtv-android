/**
 * Playlist Screen - Main video player with playlist
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  FlatList,
  TouchableOpacity,
  Image,
  RefreshControl,
} from 'react-native';
import { useTheme } from '../contexts/ThemeProvider';
import { useVideo } from '../contexts/VideoProvider';
import { Video } from '../services/YouTubeService';
import NativeVideoPlayer from '../components/NativeVideoPlayer';

export default function PlaylistScreen() {
  const { theme } = useTheme();
  const { 
    playlist, 
    currentVideoId, 
    setCurrentVideoId, 
    isLoading, 
    error, 
    refreshPlaylist 
  } = useVideo();
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = async () => {
    setRefreshing(true);
    await refreshPlaylist();
    setRefreshing(false);
  };

  const renderVideoItem = ({ item, index }: { item: Video; index: number }) => {
    const isPlaying = item.id === currentVideoId;
    
    return (
      <TouchableOpacity
        style={[
          styles.videoItem,
          { 
            backgroundColor: isPlaying ? theme.colors.accent + '20' : theme.colors.surface,
            borderColor: isPlaying ? theme.colors.accent : theme.colors.border,
          }
        ]}
        onPress={() => setCurrentVideoId(item.id)}
      >
        <Image source={{ uri: item.thumbnail }} style={styles.thumbnail} />
        <View style={styles.videoInfo}>
          <Text 
            style={[styles.videoTitle, { color: theme.colors.text }]} 
            numberOfLines={2}
          >
            {item.title}
          </Text>
          <Text style={[styles.videoMeta, { color: theme.colors.textSecondary }]}>
            {item.channelTitle} • {item.duration}
          </Text>
          <Text style={[styles.videoMeta, { color: theme.colors.textSecondary }]}>
            {item.viewCount.toLocaleString()} views
          </Text>
        </View>
        {isPlaying && (
          <View style={[styles.playingIndicator, { backgroundColor: theme.colors.accent }]}>
            <Text style={styles.playingText}>▶</Text>
          </View>
        )}
      </TouchableOpacity>
    );
  };

  if (error) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: theme.colors.background }]}>
        <View style={styles.errorContainer}>
          <Text style={[styles.errorText, { color: theme.colors.error }]}>
            Error loading playlist: {error}
          </Text>
          <TouchableOpacity
            style={[styles.retryButton, { backgroundColor: theme.colors.accent }]}
            onPress={refreshPlaylist}
          >
            <Text style={styles.retryButtonText}>Retry</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.colors.background }]}>
      {/* Video Player */}
      <View style={styles.playerContainer}>
        <NativeVideoPlayer />
      </View>

      {/* Playlist */}
      <View style={styles.playlistContainer}>
        <View style={styles.playlistHeader}>
          <Text style={[styles.playlistTitle, { color: theme.colors.text }]}>
            Live Stream Playlist
          </Text>
          <Text style={[styles.playlistCount, { color: theme.colors.textSecondary }]}>
            {playlist.length} videos
          </Text>
        </View>

        <FlatList
          data={playlist}
          keyExtractor={(item) => item.id}
          renderItem={renderVideoItem}
          style={styles.playlist}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor={theme.colors.accent}
            />
          }
          getItemLayout={(data, index) => ({
            length: 80,
            offset: 80 * index,
            index,
          })}
          initialNumToRender={10}
          maxToRenderPerBatch={10}
          windowSize={21}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  playerContainer: {
    height: 220,
  },
  playlistContainer: {
    flex: 1,
    paddingTop: 10,
  },
  playlistHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 10,
  },
  playlistTitle: {
    fontSize: 18,
    fontWeight: '600',
  },
  playlistCount: {
    fontSize: 14,
  },
  playlist: {
    flex: 1,
  },
  videoItem: {
    flexDirection: 'row',
    padding: 12,
    marginHorizontal: 16,
    marginVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
    alignItems: 'center',
  },
  thumbnail: {
    width: 56,
    height: 42,
    borderRadius: 4,
    marginRight: 12,
  },
  videoInfo: {
    flex: 1,
  },
  videoTitle: {
    fontSize: 14,
    fontWeight: '500',
    marginBottom: 4,
  },
  videoMeta: {
    fontSize: 12,
    marginBottom: 2,
  },
  playingIndicator: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 8,
  },
  playingText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 20,
  },
  retryButton: {
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
  },
  retryButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});