/**
 * Home Screen - Main dashboard with navigation to different sections
 */

import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  SafeAreaView,
  Image,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useTheme } from '../contexts/ThemeProvider';
import { useVideo } from '../contexts/VideoProvider';

export default function HomeScreen() {
  const navigation = useNavigation();
  const { theme } = useTheme();
  const { playlist, isLoading, error } = useVideo();

  const menuItems = [
    {
      title: 'Live Stream',
      description: '24/7 Decentralized News',
      icon: '🔴',
      route: 'Playlist',
      videos: playlist.length,
    },
    {
      title: 'Newsmakers',
      description: 'Creator Profiles & Stats',
      icon: '👥',
      route: 'Creators',
      videos: null,
    },
    {
      title: 'MeshNews.org',
      description: 'Browse Original Site',
      icon: '🌐',
      route: 'MeshNews',
      videos: null,
    },
    {
      title: 'Settings',
      description: 'API Keys & Preferences',
      icon: '⚙️',
      route: 'Settings',
      videos: null,
    },
  ];

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={[styles.logo, { color: theme.colors.accent }]}>MeshTV</Text>
          <Text style={[styles.tagline, { color: theme.colors.textSecondary }]}>
            24/7 Decentralized News
          </Text>
        </View>

        {/* Status */}
        <View style={[styles.statusCard, { backgroundColor: theme.colors.surface }]}>
          {isLoading ? (
            <Text style={[styles.statusText, { color: theme.colors.textSecondary }]}>
              Loading playlist...
            </Text>
          ) : error ? (
            <Text style={[styles.statusText, { color: theme.colors.error }]}>
              Error: {error}
            </Text>
          ) : (
            <Text style={[styles.statusText, { color: theme.colors.success }]}>
              ✓ Connected • {playlist.length} videos loaded
            </Text>
          )}
        </View>

        {/* Menu Items */}
        <View style={styles.menu}>
          {menuItems.map((item, index) => (
            <TouchableOpacity
              key={index}
              style={[styles.menuItem, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}
              onPress={() => navigation.navigate(item.route as never)}
            >
              <View style={styles.menuIcon}>
                <Text style={styles.iconText}>{item.icon}</Text>
              </View>
              <View style={styles.menuContent}>
                <Text style={[styles.menuTitle, { color: theme.colors.text }]}>
                  {item.title}
                </Text>
                <Text style={[styles.menuDescription, { color: theme.colors.textSecondary }]}>
                  {item.description}
                </Text>
                {item.videos && (
                  <Text style={[styles.videoCount, { color: theme.colors.accent }]}>
                    {item.videos} videos available
                  </Text>
                )}
              </View>
              <Text style={[styles.arrow, { color: theme.colors.textSecondary }]}>›</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={[styles.footerText, { color: theme.colors.textSecondary }]}>
            Powered by user devices • No servers required
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 30,
    marginTop: 20,
  },
  logo: {
    fontSize: 36,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  tagline: {
    fontSize: 16,
    textAlign: 'center',
  },
  statusCard: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 30,
    alignItems: 'center',
  },
  statusText: {
    fontSize: 16,
    fontWeight: '500',
  },
  menu: {
    gap: 16,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    borderRadius: 12,
    borderWidth: 1,
  },
  menuIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(255, 107, 53, 0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  iconText: {
    fontSize: 24,
  },
  menuContent: {
    flex: 1,
  },
  menuTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 4,
  },
  menuDescription: {
    fontSize: 14,
    marginBottom: 4,
  },
  videoCount: {
    fontSize: 12,
    fontWeight: '500',
  },
  arrow: {
    fontSize: 24,
    fontWeight: '300',
  },
  footer: {
    marginTop: 40,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 12,
    textAlign: 'center',
  },
});