/**
 * Creators Screen - Show creator profiles and stats
 */

import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  Image,
} from 'react-native';
import { useTheme } from '../contexts/ThemeProvider';
import { useVideo } from '../contexts/VideoProvider';

export default function CreatorsScreen() {
  const { theme } = useTheme();
  const { playlist } = useVideo();

  // Extract unique creators from playlist
  const creators = playlist.reduce((acc: any[], video) => {
    const existing = acc.find(c => c.channelTitle === video.channelTitle);
    if (existing) {
      existing.videoCount++;
      existing.totalViews += video.viewCount;
    } else {
      acc.push({
        channelTitle: video.channelTitle,
        videoCount: 1,
        totalViews: video.viewCount,
        thumbnail: video.thumbnail,
      });
    }
    return acc;
  }, []).sort((a, b) => b.videoCount - a.videoCount);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <Text style={[styles.title, { color: theme.colors.text }]}>
            Newsmakers
          </Text>
          <Text style={[styles.subtitle, { color: theme.colors.textSecondary }]}>
            Content creators in the MeshNews ecosystem
          </Text>
        </View>

        <View style={styles.creators}>
          {creators.map((creator, index) => (
            <View
              key={index}
              style={[styles.creatorCard, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}
            >
              <Image
                source={{ uri: creator.thumbnail }}
                style={styles.creatorAvatar}
              />
              <View style={styles.creatorInfo}>
                <Text style={[styles.creatorName, { color: theme.colors.text }]}>
                  {creator.channelTitle}
                </Text>
                <Text style={[styles.creatorStats, { color: theme.colors.textSecondary }]}>
                  {creator.videoCount} videos in playlist
                </Text>
                <Text style={[styles.creatorStats, { color: theme.colors.textSecondary }]}>
                  {creator.totalViews.toLocaleString()} total views
                </Text>
              </View>
              <View style={styles.creatorBadge}>
                <Text style={[styles.badgeText, { color: theme.colors.accent }]}>
                  #{index + 1}
                </Text>
              </View>
            </View>
          ))}
        </View>

        {creators.length === 0 && (
          <View style={styles.emptyState}>
            <Text style={[styles.emptyText, { color: theme.colors.textSecondary }]}>
              Loading creator information...
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  header: {
    marginBottom: 30,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    lineHeight: 24,
  },
  creators: {
    gap: 16,
  },
  creatorCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
  },
  creatorAvatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 16,
  },
  creatorInfo: {
    flex: 1,
  },
  creatorName: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 4,
  },
  creatorStats: {
    fontSize: 14,
    marginBottom: 2,
  },
  creatorBadge: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 107, 53, 0.1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgeText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 16,
    textAlign: 'center',
  },
});