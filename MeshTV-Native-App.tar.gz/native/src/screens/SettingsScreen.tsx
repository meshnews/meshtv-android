/**
 * Settings Screen - App configuration and API key management
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Switch,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useTheme } from '../contexts/ThemeProvider';
import { useVideo } from '../contexts/VideoProvider';
import { youTubeService } from '../services/YouTubeService';

export default function SettingsScreen() {
  const { theme, toggleTheme, isDark } = useTheme();
  const { refreshPlaylist, clearCache } = useVideo();
  const [apiKey, setApiKey] = useState('');
  const [isValidating, setIsValidating] = useState(false);

  useEffect(() => {
    loadApiKey();
  }, []);

  const loadApiKey = async () => {
    try {
      const savedKey = await AsyncStorage.getItem('youtube_api_key');
      if (savedKey) {
        setApiKey(savedKey);
      }
    } catch (error) {
      console.error('Error loading API key:', error);
    }
  };

  const updateApiKey = async () => {
    if (!apiKey.trim()) {
      Alert.alert('Error', 'Please enter a valid API key');
      return;
    }

    setIsValidating(true);
    try {
      const isValid = await youTubeService.validateApiKey(apiKey.trim());
      
      if (isValid) {
        await youTubeService.setApiKey(apiKey.trim());
        Alert.alert('Success', 'API key updated successfully!');
      } else {
        Alert.alert('Error', 'Invalid API key. Please check and try again.');
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to validate API key.');
    } finally {
      setIsValidating(false);
    }
  };

  const clearAppData = () => {
    Alert.alert(
      'Clear App Data',
      'This will clear all cached data and require you to re-enter your API key. Continue?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear',
          style: 'destructive',
          onPress: async () => {
            try {
              await AsyncStorage.clear();
              youTubeService.clearCache();
              Alert.alert('Success', 'App data cleared. Please restart the app.');
            } catch (error) {
              Alert.alert('Error', 'Failed to clear app data.');
            }
          },
        },
      ]
    );
  };

  const refreshData = async () => {
    try {
      youTubeService.clearCache();
      await refreshPlaylist();
      Alert.alert('Success', 'Data refreshed successfully!');
    } catch (error) {
      Alert.alert('Error', 'Failed to refresh data.');
    }
  };

  const settingsSections = [
    {
      title: 'API Configuration',
      items: [
        {
          type: 'input',
          title: 'YouTube API Key',
          value: apiKey,
          onChangeText: setApiKey,
          placeholder: 'Enter your YouTube API key...',
          secure: true,
        },
        {
          type: 'button',
          title: isValidating ? 'Validating...' : 'Update API Key',
          onPress: updateApiKey,
          disabled: isValidating,
        },
      ],
    },
    {
      title: 'Appearance',
      items: [
        {
          type: 'switch',
          title: 'Dark Mode',
          value: isDark,
          onValueChange: toggleTheme,
        },
      ],
    },
    {
      title: 'Data Management',
      items: [
        {
          type: 'button',
          title: 'Refresh Playlist',
          onPress: refreshData,
        },
        {
          type: 'button',
          title: 'Clear App Data',
          onPress: clearAppData,
          destructive: true,
        },
      ],
    },
  ];

  const renderSettingItem = (item: any, index: number) => {
    switch (item.type) {
      case 'input':
        return (
          <View key={index} style={styles.settingItem}>
            <Text style={[styles.settingTitle, { color: theme.colors.text }]}>
              {item.title}
            </Text>
            <TextInput
              style={[styles.input, { backgroundColor: theme.colors.background, color: theme.colors.text, borderColor: theme.colors.border }]}
              value={item.value}
              onChangeText={item.onChangeText}
              placeholder={item.placeholder}
              placeholderTextColor={theme.colors.textSecondary}
              secureTextEntry={item.secure}
              autoCapitalize="none"
              autoCorrect={false}
              multiline={!item.secure}
              numberOfLines={item.secure ? 1 : 3}
            />
          </View>
        );

      case 'button':
        return (
          <TouchableOpacity
            key={index}
            style={[
              styles.button,
              { 
                backgroundColor: item.destructive ? theme.colors.error : theme.colors.accent,
                opacity: item.disabled ? 0.5 : 1,
              }
            ]}
            onPress={item.onPress}
            disabled={item.disabled}
          >
            <Text style={styles.buttonText}>{item.title}</Text>
          </TouchableOpacity>
        );

      case 'switch':
        return (
          <View key={index} style={[styles.settingItem, styles.switchItem]}>
            <Text style={[styles.settingTitle, { color: theme.colors.text }]}>
              {item.title}
            </Text>
            <Switch
              value={item.value}
              onValueChange={item.onValueChange}
              trackColor={{ false: theme.colors.border, true: theme.colors.accent }}
              thumbColor="#ffffff"
            />
          </View>
        );

      default:
        return null;
    }
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {settingsSections.map((section, sectionIndex) => (
          <View key={sectionIndex} style={styles.section}>
            <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>
              {section.title}
            </Text>
            <View style={[styles.sectionContent, { backgroundColor: theme.colors.surface }]}>
              {section.items.map(renderSettingItem)}
            </View>
          </View>
        ))}

        <View style={styles.footer}>
          <Text style={[styles.footerText, { color: theme.colors.textSecondary }]}>
            MeshTV Native v1.0.0
          </Text>
          <Text style={[styles.footerText, { color: theme.colors.textSecondary }]}>
            Powered by user devices • No servers required
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  section: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 12,
  },
  sectionContent: {
    borderRadius: 12,
    padding: 16,
  },
  settingItem: {
    marginBottom: 16,
  },
  switchItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 8,
  },
  input: {
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    borderWidth: 1,
    minHeight: 44,
    textAlignVertical: 'top',
  },
  button: {
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 16,
    alignItems: 'center',
    marginBottom: 8,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  footer: {
    alignItems: 'center',
    marginTop: 40,
  },
  footerText: {
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 4,
  },
});