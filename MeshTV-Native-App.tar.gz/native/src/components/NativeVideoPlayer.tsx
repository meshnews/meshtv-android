/**
 * Native Video Player - YouTube player with background audio support
 */

import React, { useState, useCallback, useRef } from 'react';
import {
  View,
  StyleSheet,
  TouchableOpacity,
  Text,
  Alert,
} from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { useVideo } from '../contexts/VideoProvider';
import { useTheme } from '../contexts/ThemeProvider';

export default function NativeVideoPlayer() {
  const { currentVideoId, currentVideo, nextTrack, previousTrack, toggleFullscreen } = useVideo();
  const { theme } = useTheme();
  const [playing, setPlaying] = useState(true);
  const [playerReady, setPlayerReady] = useState(false);
  const playerRef = useRef<any>(null);

  const onStateChange = useCallback((state: string) => {
    console.log('Player state changed:', state);
    if (state === 'ended') {
      console.log('Video ended, advancing to next');
      nextTrack();
    }
  }, [nextTrack]);

  const onReady = useCallback(() => {
    setPlayerReady(true);
    console.log('YouTube player ready');
  }, []);

  const onError = useCallback((error: string) => {
    console.error('YouTube player error:', error);
    Alert.alert('Playback Error', 'There was an error playing this video. Trying next video...');
    nextTrack();
  }, [nextTrack]);

  const togglePlayPause = () => {
    setPlaying(!playing);
  };

  if (!currentVideoId) {
    return (
      <View style={[styles.container, { backgroundColor: theme.colors.surface }]}>
        <Text style={[styles.noVideo, { color: theme.colors.textSecondary }]}>
          Select a video to start playing
        </Text>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <YoutubePlayer
        ref={playerRef}
        height={220}
        width="100%"
        play={playing}
        videoId={currentVideoId}
        onChangeState={onStateChange}
        onReady={onReady}
        onError={onError}
        allowsFullscreenVideo={true}
        forceAndroidAutoplay={true}
        initialPlayerParams={{
          cc_lang_pref: 'en',
          showClosedCaptions: false,
          modestbranding: true,
          rel: false,
          iv_load_policy: 3,
        }}
      />

      {/* Control Overlay */}
      <View style={styles.controlOverlay}>
        <View style={styles.videoTitle}>
          <Text style={[styles.titleText, { color: theme.colors.text }]} numberOfLines={2}>
            {currentVideo?.title || 'Loading...'}
          </Text>
        </View>

        <View style={styles.controls}>
          <TouchableOpacity
            style={[styles.controlButton, { backgroundColor: theme.colors.surface }]}
            onPress={previousTrack}
          >
            <Text style={[styles.controlText, { color: theme.colors.text }]}>⏮</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.controlButton, { backgroundColor: theme.colors.accent }]}
            onPress={togglePlayPause}
          >
            <Text style={[styles.controlText, { color: '#fff' }]}>
              {playing ? '⏸' : '▶'}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.controlButton, { backgroundColor: theme.colors.surface }]}
            onPress={nextTrack}
          >
            <Text style={[styles.controlText, { color: theme.colors.text }]}>⏭</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.controlButton, { backgroundColor: theme.colors.surface }]}
            onPress={toggleFullscreen}
          >
            <Text style={[styles.controlText, { color: theme.colors.text }]}>⛶</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    position: 'relative',
  },
  noVideo: {
    flex: 1,
    textAlign: 'center',
    textAlignVertical: 'center',
    fontSize: 16,
  },
  controlOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    padding: 12,
  },
  videoTitle: {
    marginBottom: 12,
  },
  titleText: {
    fontSize: 14,
    fontWeight: '500',
  },
  controls: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  controlButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  controlText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});