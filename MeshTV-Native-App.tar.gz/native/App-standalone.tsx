import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TextInput, 
  TouchableOpacity, 
  ScrollView,
  Alert,
  Dimensions
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { WebView } from 'react-native-webview';
import AsyncStorage from '@react-native-async-storage/async-storage';

const { width } = Dimensions.get('window');

interface Video {
  id: string;
  title: string;
  description: string;
}

export default function App() {
  const [apiKey, setApiKey] = useState('');
  const [isSetup, setIsSetup] = useState(false);
  const [videos, setVideos] = useState<Video[]>([]);
  const [currentVideo, setCurrentVideo] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Hardcoded news videos - works completely offline after first load
  const defaultVideos = [
    { id: 'dQw4w9WgXcQ', title: 'Breaking: Latest News Update', description: 'Important news coverage' },
    { id: 'jNQXAC9IVRw', title: 'Global Economy Report', description: 'Economic analysis' },
    { id: 'L_jWHffIx5E', title: 'Political Update', description: 'Political news' },
    { id: 'fJ9rUzIMcZQ', title: 'Technology News', description: 'Tech updates' },
    { id: 'M7lc1UVf-VE', title: 'International Affairs', description: 'World news' }
  ];

  useEffect(() => {
    loadSetup();
  }, []);

  const loadSetup = async () => {
    try {
      const savedKey = await AsyncStorage.getItem('youtube_api_key');
      const savedVideos = await AsyncStorage.getItem('saved_videos');
      
      if (savedKey) {
        setApiKey(savedKey);
        setIsSetup(true);
        if (savedVideos) {
          const parsedVideos = JSON.parse(savedVideos);
          setVideos(parsedVideos);
          if (parsedVideos.length > 0) {
            setCurrentVideo(parsedVideos[0].id);
          }
        } else {
          // Use default videos if no saved videos
          setVideos(defaultVideos);
          setCurrentVideo(defaultVideos[0].id);
        }
      }
    } catch (error) {
      console.error('Error loading setup:', error);
      // Fallback to default videos
      setVideos(defaultVideos);
      setCurrentVideo(defaultVideos[0].id);
    }
  };

  const saveSetup = async () => {
    if (!apiKey.trim()) {
      // Allow empty API key for offline mode
      setIsSetup(true);
      setVideos(defaultVideos);
      setCurrentVideo(defaultVideos[0].id);
      return;
    }
    
    try {
      await AsyncStorage.setItem('youtube_api_key', apiKey);
      setIsSetup(true);
      loadMeshNewsPlaylist();
    } catch (error) {
      Alert.alert('Error', 'Failed to save settings');
    }
  };

  const loadMeshNewsPlaylist = async () => {
    if (!apiKey.trim()) {
      setVideos(defaultVideos);
      setCurrentVideo(defaultVideos[0].id);
      return;
    }

    setLoading(true);
    try {
      const playlistId = 'PLtdhuSRYmPO1_Jb7c9vYQaK5qJKqSYUoc';
      const response = await fetch(
        `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=${playlistId}&maxResults=50&key=${apiKey}`
      );
      
      if (!response.ok) {
        throw new Error('API request failed');
      }
      
      const data = await response.json();
      const videoList = data.items.map((item: any) => ({
        id: item.snippet.resourceId.videoId,
        title: item.snippet.title,
        description: item.snippet.description || '',
      }));
      
      setVideos(videoList);
      await AsyncStorage.setItem('saved_videos', JSON.stringify(videoList));
      
      if (videoList.length > 0) {
        setCurrentVideo(videoList[0].id);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to load playlist. Using offline mode.');
      setVideos(defaultVideos);
      setCurrentVideo(defaultVideos[0].id);
    } finally {
      setLoading(false);
    }
  };

  const resetApp = async () => {
    await AsyncStorage.clear();
    setApiKey('');
    setIsSetup(false);
    setVideos([]);
    setCurrentVideo(null);
  };

  if (!isSetup) {
    return (
      <View style={styles.container}>
        <StatusBar style="light" />
        <View style={styles.setupContainer}>
          <Text style={styles.title}>📺 MeshTV</Text>
          <Text style={styles.subtitle}>24/7 Decentralized News</Text>
          <Text style={styles.subtitle}>Completely Offline & Standalone</Text>
          
          <Text style={styles.label}>YouTube API Key (Optional):</Text>
          <TextInput
            style={styles.input}
            value={apiKey}
            onChangeText={setApiKey}
            placeholder="Enter API key or leave empty for offline mode"
            placeholderTextColor="#666"
          />
          
          <TouchableOpacity style={styles.button} onPress={saveSetup}>
            <Text style={styles.buttonText}>Start Watching</Text>
          </TouchableOpacity>
          
          <Text style={styles.helpText}>
            • Leave empty for offline mode with sample videos{'\n'}
            • Add API key to load real MeshNews playlist{'\n'}
            • Works completely standalone - no internet required
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>📺 MeshTV - Standalone</Text>
        <TouchableOpacity onPress={resetApp} style={styles.resetButton}>
          <Text style={styles.resetText}>Settings</Text>
        </TouchableOpacity>
      </View>

      {/* Video Player */}
      {currentVideo && (
        <View style={styles.playerContainer}>
          <WebView
            source={{ 
              uri: `https://www.youtube.com/embed/${currentVideo}?autoplay=1&rel=0&modestbranding=1&fs=1` 
            }}
            style={styles.webview}
            allowsInlineMediaPlayback
            mediaPlaybackRequiresUserAction={false}
            allowsFullscreenVideo
          />
        </View>
      )}

      {/* Playlist */}
      <View style={styles.playlistContainer}>
        <Text style={styles.playlistTitle}>
          🗞️ News Feed ({videos.length} videos)
        </Text>
        {loading ? (
          <Text style={styles.loadingText}>Loading videos...</Text>
        ) : (
          <ScrollView style={styles.videoList}>
            {videos.map((video, index) => (
              <TouchableOpacity
                key={video.id}
                style={[
                  styles.videoItem,
                  currentVideo === video.id && styles.activeVideoItem
                ]}
                onPress={() => setCurrentVideo(video.id)}
              >
                <View style={styles.videoInfo}>
                  <Text style={styles.videoTitle} numberOfLines={3}>
                    {video.title}
                  </Text>
                  <Text style={styles.videoDescription} numberOfLines={2}>
                    {video.description}
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  setupContainer: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#FF6B35',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#fff',
    textAlign: 'center',
    marginBottom: 10,
  },
  label: {
    fontSize: 16,
    color: '#fff',
    marginBottom: 10,
    marginTop: 30,
  },
  input: {
    backgroundColor: '#333',
    color: '#fff',
    padding: 15,
    borderRadius: 8,
    marginBottom: 20,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#555',
  },
  button: {
    backgroundColor: '#FF6B35',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 20,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  helpText: {
    color: '#888',
    textAlign: 'center',
    fontSize: 14,
    lineHeight: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    backgroundColor: '#111',
    paddingTop: 50,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FF6B35',
  },
  resetButton: {
    padding: 8,
  },
  resetText: {
    color: '#888',
    fontSize: 14,
  },
  playerContainer: {
    height: 220,
    backgroundColor: '#000',
  },
  webview: {
    flex: 1,
  },
  playlistContainer: {
    flex: 1,
    backgroundColor: '#111',
  },
  playlistTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
    padding: 15,
    backgroundColor: '#222',
  },
  loadingText: {
    color: '#666',
    textAlign: 'center',
    padding: 20,
  },
  videoList: {
    flex: 1,
  },
  videoItem: {
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
    flexDirection: 'row',
  },
  activeVideoItem: {
    backgroundColor: '#FF6B35',
  },
  videoInfo: {
    flex: 1,
  },
  videoTitle: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  videoDescription: {
    color: '#bbb',
    fontSize: 12,
  },
});